#pragma once
#include <iostream>
#include <cstring>
#include <cmath>

using namespace std;

class MapPoint {
  public:
    //default constructor that sets default values of "Punkt" and 0, 0 
    MapPoint();
    //constructor that sets given values of object without sides of the world
    MapPoint(const char *, double, double);
    //constructor that sets given values of object with sides of the world
    MapPoint(const char *, double, const char, double, const char);
    //prints object data
    void print() const;
    //offsets objects longitude and latitude by given values
    void movePoint(const double, const double);
    //returns MapPoint closest to this object
    MapPoint & closestPlace(MapPoint *, MapPoint *);
    //returns name
    char * getName() const;
    //returns latitude
    double getLat();
    //returns longitude
    double getLon();
    //sets name of an object
    void setName(const char *);
    //sets longitude of an object
    void setLon(double);
    //sets latitude of an object
    void setLat(double);
    //destructor
    ~MapPoint();
  private:
    char * name;
    double longitude;
    double latitude;
};

MapPoint inTheMiddle(MapPoint *, MapPoint *, const char *);
char calculateLon(double);
char calculateLat(double);
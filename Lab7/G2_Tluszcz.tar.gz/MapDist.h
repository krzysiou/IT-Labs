#include <iostream>
#include <cmath>
#include "MapPoint.h"

class MapDist{
  public:
    //constructor that calculates distances in longitude and latitude
    MapDist(MapPoint &, MapPoint &);
    //returns longitude
    double getlongitude() const;
    //returns latitude
    double getlatitude() const;
    //calculates distance based on the Pythagoras theorem
    double angularDistance () const;
    //sets latitude of object
    void setLat(double);
    //sets longitude of object
    void setLon(double);
  private:
    double distLongitude;
    double distLatitude;
};

//creates MapDist object (simillar to constructor)
MapDist distance(MapPoint &, MapPoint &);